from django.apps import AppConfig


class ClockappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'clockapp'
